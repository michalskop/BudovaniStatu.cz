/*jshint undef: true, browser:true, jquery: true, devel: true */
/*global vis4, BubbleTree */

/*
 * loads the data and initializes the bubblechart
 * you need to include the bubblechart.min.js first
 */
BubbleTree.Loader = function(config) {

	var me = this;

	me.config = config;

	me.ns = BubbleTree;

	/*
	 * loads data from a local JSON file
	 */
	me.loadData = function() {
		var me = this, url = me.config.data;
		console.log('loading url ',url);
		$.ajax({
			url: url,
			context: me,
			dataType: 'json',
			success: function(data) {
				this.run(data);
			}
		});
	};

	/*
	 * run will be called by dataLoaded once, well, the data is loaded
	 */
	me.run = function(data) {
		var me = this;
		// initialize bubble chart
		var bubbleChart = new BubbleTree(
			me.config
		);
		bubbleChart.setData(data);
		me.config.instance = bubbleChart;
	};

	if (!me.config.hasOwnProperty('data')) {
		//console.error('BubbleTree Error: no data set', me.config);
	}
	if (typeof me.config.data == "string") {
		// use the given js object
		me.loadData();
	} else {
		// load local tree json file
		me.run(me.config.data);
	}
};

